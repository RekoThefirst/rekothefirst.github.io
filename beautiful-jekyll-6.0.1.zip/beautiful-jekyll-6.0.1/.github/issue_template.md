Please only submit feature suggestions or bug reports if you believe something is broken.

If you need help, or if you enjoy Beautiful Jekyll and want to support it, please upgrade to one of our plans: https://beautifuljekyll.com/plans/
